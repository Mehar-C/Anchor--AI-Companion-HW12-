import SwiftUI
import WatchKit

@main
struct AnchorWatchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

